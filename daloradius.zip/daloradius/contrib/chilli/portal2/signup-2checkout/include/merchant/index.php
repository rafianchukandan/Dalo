<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Payment Gateway Tests</title>
</head>
<body>
    <h1>Payment Gateway Tests</h1>
    <ul>
        <li><a href="paypal_start.php">Paypal</li>
        <li><a href="authorize_start.php">Authorize.net</li>
        <li><a href="2co_start.php">2CheckOut</li>
    </ul>
</body>
</html>
